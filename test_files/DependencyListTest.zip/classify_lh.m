function classV = classify_lh(v, upperV)
% Sort elements of v into classes
%{
% TASK:
%  Given upper bounds for classes (upperV)
%  Return a vector that indicates which class element
%  i belongs to
%  That is:  upperV(classV(i)-1) < v(i) <= upperV(classV(i))
%  Everything beyond the last element of upperV is put into
%  the (n+1)st class

% IN:
%  v        vector of numbers
%  upperV   upper bounds of classes (sorted, ascending)

% OUT:
%  classV   see above; same length as v

Better: histc
   Difference: it returns i1 such that v(i1) < upperV(i1)

% TEST:  t_classify.m

% AUTHOR: Lutz Hendricks, 1997
%}
% ---------------------------------------

if nargin ~= 2
   error('Invalid nargin');
end

n = length( upperV );
classV = (n+1) .* ones(size(v));

for i1 = n : -1 : 1
   classV(v <= upperV(i1)) = i1;
end

end
