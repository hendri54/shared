function warnmsg(text1, text2, text3, text4)
% warnMsg: Display a warning message
% IN:
%   texts to be displayed. Missing arguments are allowed
%  mNameStr: mfilename of calling function
% ---------------------------------------------

% Get function from which warnmsg is called
stackS = dbstack;

disp(' ')
disp('<<< !! WARNING !! >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
disp([stackS(2).name, ':  ',  text1])
if nargin >= 2
    disp(text2)
end
if nargin >= 3
    disp(text3)
end
if nargin >= 4
    disp(text4)
end
disp('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')

end