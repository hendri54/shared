function [clLbIdxV, clUbIdxV, clLbV, clUbV] = cl_bounds_lh(clUbInV, n, dbg);
% Given class upper bounds in clUbInV and n observations.
% Find class lower bounds and upper bounds in fractions (clLbV, clUbV)
% and in indices (clLbIdxV, clUbIdxV) such that observations
% in clLbIdxV(i) : clUbIdxV(i) cover the percentage range
% in clLbV(i) : clUbV(i)

% This is a helper routine for functions that sort observations into
% percentage classes

% IN:
%  clUbInV     Percentile upper bounds of classes

% OUT:
%  clUbV    Class upper bounds. In [0, 1]. Typically the same as clUbInV
%           But may append a top class so that clUbV(end) = 1

% ------------------------------------------------------------

% *****  Input check  *****

clUbV = clUbInV;
if max(clUbV) > 1  |  clUbV(1) <= 0
   abort([ mfilename, ': Inputs must be percentage classes' ]);
end
% Append top upper bound if needed
if clUbV(end) < 0.9999
   clUbV = [clUbV, 1];
else
   clUbV(end) = 1;
end
% Class lower bounds
clLbV = [0, clUbV(1:end-1)];
% No of classes
nc = length(clUbV);


% Find index range for each class
clUbIdxV = max(1, round( n .* clUbV ));
clLbIdxV = min(n, [1, clUbIdxV(1:nc-1)+1]);

% Make sure that no two entries are the same
clSizeV = clUbIdxV - clLbIdxV + 1;
if any(clSizeV <= 0)
   warnmsg([ mfilename, ':  Zero or negative class size' ]);
   keyboard;
end

if dbg > 10
   v_check( clUbIdxV, 'i', [1,nc], 1, n );
   v_check( clLbIdxV, 'i', [1,nc], 1, n );
end

% **********  eof  *****************
