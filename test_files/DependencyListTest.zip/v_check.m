function vValid = v_check(vIn, dataType, vSize, minVal,maxVal, missVal)
% Check a variable against several restrictions.
% ---------------------------------------
% TASK:
%  v_check(v, dataType, vSize, minVal,maxVal);
%  This is a debugging tool similar to 'assert'
%  If a restriction is violated: Warning message and vValid = 0
%{
% IN:
%  v           variable
%  dataType    'i' = integer; 'f' = float; 's' = string
%  vSize       size of v
%  minVal      lower bound
%  maxVal      upper bound
   missVal     missing value code; ignored when computing min/max

% OUT:
%  vValid      Variable is valid: 1; Not valid: 0

% REM:
%  To omit an input set it to []

% TEST:

% AUTHOR: Lutz Hendricks, 1995
%}
% ---------------------------------------


if nargin < 5
   error('Invalid nargin');
end
if nargin < 6
   missVal = [];
end



% ******************  TESTS  ********************************

vValid = 1;
v = vIn(:);

if isnumeric(v)
   try
      validateattributes(v, {'numeric'}, {'real', 'finite', 'nonnan', 'nonempty'});
   catch
      warnmsg('Input not finite float');
      vValid = 0;
      return;
   end
elseif isempty(v)
   warnmsg('Input empty');
   vValid = 0;
   return;
end

% if any( isinf(v) )
%    warnmsg('Inf encountered');
%    vValid = 0;
%    return;
% end
% if any( isnan(v) )
%    warnmsg('NaN encountered');
%    vValid = 0;
%    return;
% end
% % Complex numbers?
% if any( imag(v) ~= 0 )
%    warnmsg('Complex numbers encountered.');
%    vValid = 0;
%    return;
% end


% *** Data Type ***
%  'f' imposes no restrictions; one could check that it is not string
if ~isempty(dataType) 
   if dataType == 's'
      if (~ischar(v))
         warnmsg('Input not a string');
         vValid = 0;
         return;
      end
   elseif dataType == 'i'
      if any(rem(v,1) ~= 0)
         warnmsg('Input not integer');
         vValid = 0;
         return;
      end
      
   elseif dataType == 'f'
      if ~isnumeric(v)
         warnmsg('Input not finite float');
         vValid = 0;
         return;
      end
   else
      warnmsg([ mfilename, ':  Invalid dataType.' ]);
      vValid = 0;
      return;
   end
end



% *** Size ***
if ~isempty(vSize)
   % Drop trailing singleton dimensions from vSize
   idxV = find( vSize ~= 1 );
   % Keep at least 2 dimensions (Matlab rule)
   if length(idxV) < 1
      tgSize = [1,1];
   else
      tgSize = vSize(1 : max(2, idxV(end)));
   end
   inputSize = size(vIn);

   if length(tgSize) ~= length(inputSize)
      disp(' ');
      tmp = sprintf('Soll: %i  Ist: %i', length(tgSize), length(inputSize) );
      warnmsg([ mfilename, ': Invalid dimensionality of input. ' ], tmp);
      vValid = 0;
      return;
   end

   if any( inputSize ~= tgSize )
      disp(' ');
      tmp1 = ['  Soll:  ',  sprintf(' %3i', tgSize)];
      tmp2 = ['   Ist:  ',  sprintf(' %3i', inputSize)];
      warnmsg('Invalid size of input', tmp1, tmp2);
      vValid = 0;
      return;
   end
end


% *** Bounds ***
checkBounds = ~isempty(minVal)  ||  ~isempty(maxVal);
if checkBounds
   if isempty(missVal)
      v2 = v;
   else
      v2 = v(v ~= missVal);
   end
   if ~isempty(v2)
      if ~isempty(minVal)
         if any(v2 < minVal)
            warnmsg( 'Input < minVal', num2str(min(v2)) );
            vValid = 0;
            return;
         end
      end
      if ~isempty(maxVal)
         if any(v2 > maxVal)
            warnmsg( 'Input > maxVal', num2str(max(v2)));
            vValid = 0;
            return;
         end
      end
   end
end

end
